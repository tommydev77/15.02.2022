import './components/fayozbek/fa.css';
import FaNav from './components/fayozbek/FaNav';
import {
  BrowserRouter as Router,
  Routes,
  Route,
  Link
} from "react-router-dom";
import Home from './components/home/Home';
import Shop from './components/shop/shop';
import Object1 from './components/objects/obj1/Objects.jsx';
import NotFound from './components/404/404';



function App() {
  return (
    <>
      {/* <FaNav /> */}
      <Router>
        <FaNav />

        <Routes>
          <Route path="/" element={<Object1 />}/>
          <Route path="/shop" element={<Shop/>}/>
          <Route path="/objects/ob1" element={<Object1/>}/>
          <Route path="*" element={<NotFound/>}/>
        </Routes>
     </Router>
    </>
  );
}



export default App;





/* <FaSlider />
<FaCards />
<FaProductLink />
<Jatitle title="Responsive" text="Lorem ipsum dolor sit amet consectetur adipisicing elit. Reiciendis nobis quae, quos sed natus quas fuga magnam deserunt?"/>
<JaCarousel/>
<JaSofa/>
<Jatitle title="Responsive" text="Lorem ipsum dolor sit amet consectetur adipisicing elit. Reiciendis  nobis quae, quos sed natus quas fuga magnam deserunt?"/>
<FaProductLink />
<FaGrid />
<JaFooter/> */