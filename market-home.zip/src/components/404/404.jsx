import React, { Component } from "react";

class NotFound extends Component {
  render() {
    return (
      <>
        <h1>
          <center className="my-5 py-5 text-danger fw-bold">Not Found 404 {":)"}</center>
        </h1>
      </>
    );
  }
}

export default NotFound;
