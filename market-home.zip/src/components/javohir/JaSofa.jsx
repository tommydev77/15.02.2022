import React from 'react'
import SofaImg from './images/sofa.png'
import './ja.css'

const JaSofa = () =>{
  return(
    <>
      <div className="container" style={{marginTop: "10%"}}>
         <div className="row ja__sofa">
           <div className="col-3" style={{paddingTop: "100px"}}>
             <h3>Beautiful Sofa</h3>
             <h5>From $509</h5>
             <p>Lorem ipsum dolor sit amet consectetur adipisicing.</p>
           </div>
           <div className="col-9">
             <img src={SofaImg} className="ja__sofaimg" alt="3D sofa from 3D shop" />
           </div>
         </div>
      </div>
    </>
  )
}

export default JaSofa