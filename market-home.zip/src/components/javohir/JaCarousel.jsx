import React, { Component } from "react";
import Slider from "react-slick";
import './ja.css'

export default class JaCarousel extends Component {
  render() {
    var settings = {
      dots: true,
      infinite: true,
      speed: 500,
      slidesToShow: 4,
      slidesToScroll: 4,
      initialSlide: 0,
      responsive: [
        {
          breakpoint: 1024,
          settings: {
            slidesToShow: 3,
            slidesToScroll: 3,
            infinite: true,
            dots: true
          }
        },
        {
          breakpoint: 600,
          settings: {
            slidesToShow: 2,
            slidesToScroll: 2,
            initialSlide: 2
          }
        },
        {
          breakpoint: 480,
          settings: {
            slidesToShow: 1,
            slidesToScroll: 1
          }
        }
      ]
    };
    return (
      <div className="container">
      
        <Slider {...settings} className="pt-5">
          <div className="ja__carousel">
            <img src="https://images.unsplash.com/photo-1613525850352-52de526e2336?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=739&q=80" width={"90%"} alt="" />
            <div className="row">
              <div className="col">
              <small>Salom Hammaga</small>
              <b>$37.12</b> 
              </div>
              <div className="col text-end mx-5">
              <i className="fal fa-heart"></i>
              <div className="ja_stars">
                <i className="fas fa-star"></i>
              <i className="fas fa-star"></i>
              <i className="fas fa-star"></i>
              
              </div>
              </div>
            </div>
          </div>
          <div className="ja__carousel">
          <img src="https://images.unsplash.com/photo-1613525850352-52de526e2336?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=739&q=80" width={"90%"} alt="" />
          <div className="row">
              <div className="col">
              <small>Salom Hammaga</small>
              <b>$37.12</b> 
              </div>
              <div className="col-4 text-end mx-5">
              <i className="fal fa-heart"></i>
              <div className="ja_stars">
                <i className="fas fa-star"></i>
              <i className="fas fa-star"></i>
              <i className="fas fa-star"></i>
              
              </div>
              </div>
            </div>
          </div>
          <div className="ja__carousel">
          <img src="https://images.unsplash.com/photo-1613525850352-52de526e2336?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=739&q=80" width={"90%"} alt="" />
          <div className="row">
              <div className="col">
              <small>Salom Hammaga</small>
              <b>$37.12</b> 
              </div>
              <div className="col-4 text-end mx-5">
              <i className="fal fa-heart"></i>
              <div className="ja_stars">
                <i className="fas fa-star"></i>
              <i className="fas fa-star"></i>
              <i className="fas fa-star"></i>
              
              </div>
              </div>
            </div>
          </div>
          <div className="ja__carousel">
          <img src="https://images.unsplash.com/photo-1613525850352-52de526e2336?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=739&q=80" width={"90%"} alt="" />
          <div className="row">
              <div className="col">
              <small>Salom Hammaga</small>
              <b>$37.12</b> 
              </div>
              <div className="col-4 text-end mx-5">
              <i className="fal fa-heart"></i>
              <div className="ja_stars">
                <i className="fas fa-star"></i>
              <i className="fas fa-star"></i>
              <i className="fas fa-star"></i>
             
              </div>
              </div>
            </div>
          </div>
          <div className="ja__carousel">
          <img src="https://images.unsplash.com/photo-1613525850352-52de526e2336?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=739&q=80" width={"90%"} alt="" />
          <div className="row">
              <div className="col">
              <small>Salom Hammaga</small>
              <b>$37.12</b> 
              </div>
              <div className="col-4 text-end mx-5">
              <i class="fal fa-heart"></i>
              <div className="ja_stars">
                <i className="fas fa-star"></i>
              <i className="fas fa-star"></i>
              <i className="fas fa-star"></i>
             </div> 
              </div>
            </div>
          </div>
          <div className="ja__carousel">
          <img src="https://images.unsplash.com/photo-1613525850352-52de526e2336?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=739&q=80" width={"90%"} alt="" />
          <div className="row">
              <div className="col">
              <small>Salom Hammaga</small>
              <b>$37.12</b> 
              </div>
              <div className="col-4 text-end mx-5">
              <i className="fal fa-heart"></i>
              <div className="ja_stars">
                <i className="fas fa-star"></i>
              <i className="fas fa-star"></i>
              <i className="fas fa-star"></i>
              
              </div>
              </div>
            </div>
          </div>
          <div className="ja__carousel">
          <img src="https://images.unsplash.com/photo-1613525850352-52de526e2336?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=739&q=80" width={"90%"} alt="" />
          <div className="row">
              <div className="col">
              <small>Salom Hammaga</small>
              <b>$37.12</b> 
              </div>
              <div className="col-4 text-end mx-5">
              <i className="fal fa-heart"></i>
              <div className="ja_stars">
                <i className="fas fa-star"></i>
              <i className="fas fa-star"></i>
              <i className="fas fa-star"></i>
              </div> 
              </div>
            </div>
          </div>
          <div className="ja__carousel">
          <img src="https://images.unsplash.com/photo-1613525850352-52de526e2336?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=739&q=80" width={"90%"} alt="" />
          <div className="row">
              <div className="col">
              <small>Salom Hammaga</small>
              <b>$37.12</b> 
              </div>
              <div className="col-4 text-end mx-5">
              <i className="fal fa-heart"></i>
              <div className="ja_stars">
                <i className="fas fa-star"></i>
              <i className="fas fa-star"></i>
              <i className="fas fa-star"></i>
             
              </div>
              </div>
            </div>
          </div>
        </Slider>
      </div>
    );
  }
}
