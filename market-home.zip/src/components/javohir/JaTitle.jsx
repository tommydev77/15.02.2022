import React from 'react';

const Jatitle = (props) => {
    return (
        <div className='mt-5'>
            <div className="text-center">
            <h3>{props.title}</h3>
            <p className="text-secondary">{props.text}</p>
            </div>
        </div>
    );
}

export default Jatitle;
