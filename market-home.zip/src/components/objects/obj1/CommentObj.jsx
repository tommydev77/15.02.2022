

function CommentObj() {
  return (
    <>
      <div>
        <section className="infoCreator pt-5">
          <div className="container">
            <h3 className="creatorName">Name Surname</h3>
            <div className="productName">
              <div className="productOwn">
                <img src="./img/faceOwn.jfif" alt="Creator 3D" />
                <div className="foxdevuzAdd">
                  <h2 className="creatorName2">Harri</h2>
                  <div className="statusUser">PRO</div>
                </div>
                <button className="follow">Follow</button>
              </div>
              <div className="downloadInfo">
                <i className="fa-regular fa-eye" />
                <span className="pm">25k</span>
                <i className="fa-solid fa-download" />
                <span className="pm">19k</span>
                <i className="fa-regular fa-heart" />
                <span className="pm">16k</span>
              </div>
            </div>
            <p className="addentional">
              <i className="fa-solid fa-download" />
              <span>Download 3D Model</span>
              <i className="fa-solid fa-plus" /> <span>Add To</span>
              <i className="fa-solid fa-share" /> <span>Share</span>
            </p>
            <hr />
          </div>
          <div className="container">
            <div className="pordoctInfo">
              <p>Name Product</p>
              <p className="info">
                Lorem ipsum, dolor sit amet consectetur adipisicing elit. Beatae
                officiis culpa animi officia unde aspernatur dolorum quaerat
                natus et perferendis accusantium facilis earum similique tenetur
                assumenda fuga, dicta fugit tempora, tempore libero maiores in
                atque harum. Porro odit velit quam reprehenderit natus earum,
                corrupti fugiat enim quo ipsum beatae debitis adipisci fugit,
                eum repudiandae quae vel, autem id officiis. Minima
              </p>
            </div>
          </div>
        </section>
        {/* Comments section */}
        <section className="comment pb-5">
          <div className="container">
            <input
              type="text"
              name
              id="comment"
              placeholder="Enter Yur Comment"
            />
            <button type="submit" id="send">
              <i className="fa-solid fa-paper-plane" />
            </button>
            <div className="commentArea" id="commentArea"></div>
          </div>
        </section>
      </div>
    </>
  );
}

export default CommentObj;
