function MainObj() {
  return (
    <>
      <div>
        <div className="container py-5">
          <div className="view-box">
            <h1>
              <img
                src="http://cliparts.co/cliparts/yik/rkr/yikrkrR4T.png"
                className="img-fluid"
                alt=""
              />
            </h1>
          </div>
        </div>
        <div className="container py-5 my-5">
          <div className="box-sliders">
            <div className="row">
              <div className="col-md-3 my-3">
                <img
                  src="http://cliparts.co/cliparts/yik/rkr/yikrkrR4T.png"
                  className="img-fluid"
                  alt=""
                />
              </div>
              <div className="col-md-3 my-3">
                <img
                  src="http://cliparts.co/cliparts/yik/rkr/yikrkrR4T.png"
                  className="img-fluid"
                  alt=""
                />
              </div>
              <div className="col-md-3 my-3">
                <img
                  src="http://cliparts.co/cliparts/yik/rkr/yikrkrR4T.png"
                  className="img-fluid"
                  alt=""
                />
              </div>
              <div className="col-md-3 my-3">
                <img
                  src="http://cliparts.co/cliparts/yik/rkr/yikrkrR4T.png"
                  className="img-fluid"
                  alt=""
                />
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}

export default MainObj;
