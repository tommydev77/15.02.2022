import MainObj from "./MainObj.jsx";
import CommentObj from "./CommentObj.jsx";


import './ObjStyle/obj.css';
function Objects() {
  return (
    <>
      <MainObj />
      <CommentObj />
    </>
  );
}

export default Objects;
