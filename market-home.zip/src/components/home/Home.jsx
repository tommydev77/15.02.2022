import '../fayozbek/fa.css';
import FaSlider from '../fayozbek/FaSlider';
import FaCards from '../fayozbek/FaCards';
import FaProductLink from '../fayozbek/FaProductLink';
import JaCarousel from '../javohir/JaCarousel'
import Jatitle from '../javohir/JaTitle';
import JaSofa from '../javohir/JaSofa'
import JaFooter from '../javohir/JaFooter';
import FaGrid from '../fayozbek/FaGrid';

function Home() {
  return (
    <>
      <FaSlider />
      <FaCards />
      <FaProductLink />
      <Jatitle title="Responsive" text="Lorem ipsum dolor sit amet consectetur adipisicing elit. Reiciendis nobis quae, quos sed natus quas fuga magnam deserunt?"/>
      <JaCarousel/>
      <JaSofa/>
      <Jatitle title="Responsive" text="Lorem ipsum dolor sit amet consectetur adipisicing elit. Reiciendis  nobis quae, quos sed natus quas fuga magnam deserunt?"/>
      <FaProductLink />
      <FaGrid />
      <JaFooter/>
    </>
  );
}



export default Home;
