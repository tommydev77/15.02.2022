import React, { Component } from "react";

class FaCars extends Component {
  render() {
    return (
      <>
        <div className="fa-cards">
          <div className="container">
            <div className="fa-card">
              <img
                className="fa-card_image1"
                src={require('./fa-images/obj_card1.png')}
                alt="3D SHOP"
              />
              <br />
              <br />
              <br />
              <p className="fa--grey">Cheap and High Quality</p>
              <h3>Beautiful Guitar</h3>
            </div>
            <div className="fa-card">
              <img
                className="fa-card_image2"
                src={require('./fa-images/obj_card2.png')}
                alt="3D SHOP"
              />
              <p className="fa--grey">3D Model</p>
              <h3>
                Save up to <br /> <span className="fa--color-font fw-bold">50% OFF</span>
              </h3>
              <p className="fa--grey">Stool</p>
            </div>
            <div className="fa-card">
              <img
                className="fa-card_image3"
                src={require('./fa-images/obj_card3.png')}
                alt="3D SHOP"
              />
              <p className="fa--grey">3D Model</p>
              <h3>
                Living Project <br /> Up To{" "}
                <span className="fa--color-font fw-bold">70% OFF</span>
              </h3>
              <p className="fa--grey">3D Model Clock</p>
            </div>
          </div>
        </div>
      </>
    );
  }
}

export default FaCars;
