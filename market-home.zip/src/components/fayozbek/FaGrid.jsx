import React, { Component } from "react";
import GridImage from './fa-images/clock-grid1.png'
class FaGrid extends Component {
  render() {
    return (
      <>
        <div className="container">
          <div className="row my-5 py5">
            <div className="col-lg-12 text-center text-uppercase">
              <h2 className="text-center">featured products</h2>
              <p className="w-50 m-auto">
                Lorem ipsum dolor sit amet consectetur adipisicing elit. Rem
                nihil corporis sapiente, maiores pariatur a illo voluptatem.
              </p>
            </div>
          </div>
          <div className="row">
            <div className="col-md-6">
              <div className="item big">
                <img src={GridImage} className="img-fluid" alt="3dSHOPImage" />
                <p>3D Model Clock</p>
                <h6>2.99$</h6>
              </div>
              <div className="row">
                <div className="col-6">
                  <div className="item">
                    <img
                      className="img-fluid"
                      src={GridImage}
                      alt="3d SHOP Image1"
                    />
                    <p>3D Model Clock</p>
                    <h6>2.99$</h6>
                  </div>
                </div>
                <div className="col-6">
                  <div className="item">
                    <img
                      className="img-fluid"
                      src={GridImage}
                      alt="3d SHOP Image2"
                    />
                    <p>3D Model Clock</p>
                    <h6>2.99$</h6>
                  </div>
                </div>
              </div>
            </div>
            <div className="col-md-6 my-5 py-6">
              <div className="row">
                <div className="col-6">
                  <div className="item">
                    <img
                      className="img-fluid"
                      src={GridImage}
                      alt="3d SHOP Image3"
                    />
                    <p>3D Model Clock</p>
                    <h6>2.99$</h6>
                  </div>
                </div>
                <div className="col-6">
                  <div className="item">
                    <img
                      className="img-fluid"
                      src={GridImage}
                      alt="3d SHOP Image4"
                    />
                    <p>3D Model Clock</p>
                    <h6>2.99$</h6>
                  </div>
                </div>
              </div>
              <div className="item big">
                <img className="img-fluid" src={GridImage} alt="3d SHOP Image5" />
                <p>3D Model Clock</p>
                <h6>2.99$</h6>
              </div>
            </div>
          </div>
        </div>
      </>
    );
  }
}

export default FaGrid;
