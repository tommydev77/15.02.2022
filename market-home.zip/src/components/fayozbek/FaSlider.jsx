import React, { Component } from "react";
import Slider from "react-slick";
class FaSlider extends Component {
  render() {
    const settings = {
      dots: true,
      infinite: true,
      speed: 500,
      slidesToShow: 1,
      slidesToScroll: 1,
    };

    return (
      <>
          <div className="fa-slider_pages py-5">
            <Slider {...settings} className="container px-3 py-5">
              <div>
                <div className="fa-slider_page1 py-3">
                  <div className="fa-slider_left">
                    <h2>Modern House 3D Model</h2>
                    <p className="fa--grey">
                      Lorem ipsum dolor, sit amet consectetur adipisicing elit.
                      Beatae cumque. Beatae cumque Beatae cumque
                    </p>
                    <button className="fa--btn">BUY NOW</button>
                  </div>
                  <div className="fa-slider_right">
                    <img
                      src={require("./fa-images/obj_house.png")}
                      alt="House 3D"
                    />
                  </div>
                </div>
              </div>
              <div>
                <div className="fa-slider_page1">
                  <div className="fa-slider_left">
                    <h2>Modern House 3D Model</h2>
                    <p className="fa--grey">
                      Lorem ipsum dolor, sit amet consectetur adipisicing elit.
                      Beatae cumque. Beatae cumque Beatae cumque
                    </p>
                    <button className="fa--btn">BUY NOW</button>
                  </div>
                  <div className="fa-slider_right">
                    <img
                      src={require("./fa-images/obj_house.png")}
                      alt="House 3D"
                    />
                  </div>
                </div>
              </div>
              <div>
                <div className="fa-slider_page1">
                  <div className="fa-slider_left">
                    <h2>Modern House 3D Model</h2>
                    <p className="fa--grey">
                      Lorem ipsum dolor, sit amet consectetur adipisicing elit.
                      Beatae cumque. Beatae cumque Beatae cumque
                    </p>
                    <button className="fa--btn">BUY NOW</button>
                  </div>
                  <div className="fa-slider_right">
                    <img
                      src={require("./fa-images/obj_house.png")}
                      alt="House 3D"
                    />
                  </div>
                </div>
              </div>
            </Slider>
          </div>
      </>
    );
  }
}

export default FaSlider;
