import React, { Component } from "react";
import { BrowserRouter as Router, Switch, Route, Link } from "react-router-dom";

window.addEventListener('scroll', () => {
  if (window.scrollY > 0) {
    document.querySelector('header').style.boxShadow = '0 0 15px rgba(0, 0, 0, 0.404)';
  }

  else {
    document.querySelector('header').style.boxShadow = '0 0 0px rgba(0, 0, 0, 0.404)';
  }
})

class FaNav extends Component {
  toggleNav = () => {
    document.querySelector(".fa-lists").classList.toggle("fa-listsResponse");
    document.querySelector(".statistika").classList.toggle("fa-listsResponse");
  };

  render() {
    return (
      <>
        <header className="header">
          <div className="container">
            <nav>
              <div className="nav-logo text-warning">SHOP</div>
              <ul className="fa-lists">
                <li>
                  <Link to="/">
                    <a>HOME</a>
                  </Link>
                </li>
                <li>
                  <Link to="/shop">
                    <a>SHOP</a>
                  </Link>
                </li>
                <li>
                  <Link to="/shop">
                    <a>CATEGORIES</a>
                  </Link>
                </li>
                <li>
                  <Link to="/shop">
                    <a>CONTACT</a>
                  </Link>
                </li>
                <li>
                  <Link to="/shop">
                    <a>BLOG</a>
                  </Link>
                </li>
              </ul>
              <div className="statistika">
                <i className="far fa-search" />
                <i className="far fa-heart"> (50) </i>
                <i className="far fa-shopping-cart"> (23) </i>
              </div>
              <i
                className="fa fa-bars"
                onClick={() => {
                  this.toggleNav();
                }}
              ></i>
            </nav>
          </div>
        </header>
      </>
    );
  }
}

export default FaNav;
