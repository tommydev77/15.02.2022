import React, { Component } from "react";

class FaProductLink extends Component {
  render() {
    return (
      <>
        <div className="fa-productLinks">
          <div className="container">
            <div className="fa-productLink">
              <i className="fal fa-chair" />
              <p className="fa--grey">Chairs</p>
            </div>
            <div className="fa-productLink">
              <i className="fal fa-house" />
              <p className="fa--grey">Houses</p>
            </div>
            <div className="fa-productLink">
              <i className="fal fa-car" />
              <p className="fa--grey">Vehicles</p>
            </div>
            <div className="fa-productLink">
              <i className="fal fa-swords" />
              <p className="fa--grey">Weapons</p>
            </div>
            <div className="fa-productLink">
              <i className="fal fa-robot" />
              <p className="fa--grey">Robots</p>
            </div>
            <div className="fa-productLink">
              <i className="fal fa-phone-laptop" />
              <p className="fa--grey">Gadgets</p>
            </div>
          </div>
        </div>
      </>
    );
  }
}

export default FaProductLink;
