import ProductImage from "./ShopImages/productImage.png";
import { BrowserRouter as Router, Routes, Route, Link } from "react-router-dom";
function ShopMain() {
  return (
    <>
      <div className="container mt-5">
        <div className="row pt-3 pb-2">
          <div className="col-12">
            <a href="res" className="text-dark mx-2 my-3 fw-bold">
              210 Resourses
            </a>
            <a href="ress" className="text-secondary mx-2 my-3">
              10 Profiles
            </a>
          </div>
        </div>
        <div className="row">
          <div className="shop-cards">
              <div className="shop-card">
                <div className="shop-card__head">
                  <img
                    src={ProductImage}
                    className="img-fluid"
                    alt="3D SHOP Image1"
                  />
                </div>
                <div className="shop-card__body">
                  <div className="shop-card__body__left">
                    Unique Collection
                    <br />
                    <span className="text-secondary">$121.44</span>
                  </div>
                  <div className="shop-card__body__right">
                    <i className="fa fa-shopping-cart p-1 m-1  rounded-circle border-secondary"></i>
                    <i className="fa fa-heart p-1 m-1  rounded-circle border-secondary"></i>
                  </div>
                </div>
              </div>
            <div className="shop-card">
              <div className="shop-card__head">
                <img
                  src={ProductImage}
                  className="img-fluid"
                  alt="3D_SHOP_Image_2"
                />
              </div>
              <div className="shop-card__body">
                <div className="shop-card__body__left">
                  Unique Collection
                  <br />
                  <span className="text-secondary">$121.44</span>
                </div>
                <div className="shop-card__body__right">
                  <i className="fa fa-shopping-cart p-1 m-1  rounded-circle border-secondary"></i>
                  <i className="fa fa-heart p-1 m-1  rounded-circle border-secondary"></i>
                </div>
              </div>
            </div>
            <div className="shop-card">
              <div className="shop-card__head">
                <img
                  src={ProductImage}
                  className="img-fluid"
                  alt="3D SHOPImage3"
                />
              </div>
              <div className="shop-card__body">
                <div className="shop-card__body__left">
                  Unique Collection
                  <br />
                  <span className="text-secondary">$121.44</span>
                </div>
                <div className="shop-card__body__right">
                  <i className="fa fa-shopping-cart p-1 m-1  rounded-circle border-secondary"></i>
                  <i className="fa fa-heart p-1 m-1  rounded-circle border-secondary"></i>
                </div>
              </div>
            </div>
            <div className="shop-card">
              <div className="shop-card__head">
                <img src={ProductImage} className="img-fluid" alt="Image1" />
              </div>
              <div className="shop-card__body">
                <div className="shop-card__body__left">
                  Unique Collection
                  <br />
                  <span className="text-secondary">$121.44</span>
                </div>
                <div className="shop-card__body__right">
                  <i className="fa fa-shopping-cart p-1 m-1  rounded-circle border-secondary"></i>
                  <i className="fa fa-heart p-1 m-1  rounded-circle border-secondary"></i>
                </div>
              </div>
            </div>
            <div className="shop-card">
              <div className="shop-card__head">
                <img
                  src={ProductImage}
                  className="img-fluid"
                  alt="3D SHOP Image1"
                />
              </div>
              <div className="shop-card__body">
                <div className="shop-card__body__left">
                  Unique Collection
                  <br />
                  <span className="text-secondary">$121.44</span>
                </div>
                <div className="shop-card__body__right">
                  <i className="fa fa-shopping-cart p-1 m-1  rounded-circle border-secondary"></i>
                  <i className="fa fa-heart p-1 m-1  rounded-circle border-secondary"></i>
                </div>
              </div>
            </div>
            <div className="shop-card">
              <div className="shop-card__head">
                <img
                  src={ProductImage}
                  className="img-fluid"
                  alt="3D_SHOP_Image_2"
                />
              </div>
              <div className="shop-card__body">
                <div className="shop-card__body__left">
                  Unique Collection
                  <br />
                  <span className="text-secondary">$121.44</span>
                </div>
                <div className="shop-card__body__right">
                  <i className="fa fa-shopping-cart p-1 m-1  rounded-circle border-secondary"></i>
                  <i className="fa fa-heart p-1 m-1  rounded-circle border-secondary"></i>
                </div>
              </div>
            </div>
            <div className="shop-card">
              <div className="shop-card__head">
                <img
                  src={ProductImage}
                  className="img-fluid"
                  alt="3D SHOPImage3"
                />
              </div>
              <div className="shop-card__body">
                <div className="shop-card__body__left">
                  Unique Collection
                  <br />
                  <span className="text-secondary">$121.44</span>
                </div>
                <div className="shop-card__body__right">
                  <i className="fa fa-shopping-cart p-1 m-1  rounded-circle border-secondary"></i>
                  <i className="fa fa-heart p-1 m-1  rounded-circle border-secondary"></i>
                </div>
              </div>
            </div>
            <div className="shop-card">
              <div className="shop-card__head">
                <img src={ProductImage} className="img-fluid" alt="Image1" />
              </div>
              <div className="shop-card__body">
                <div className="shop-card__body__left">
                  Unique Collection
                  <br />
                  <span className="text-secondary">$121.44</span>
                </div>
                <div className="shop-card__body__right">
                  <i className="fa fa-shopping-cart p-1 m-1  rounded-circle border-secondary"></i>
                  <i className="fa fa-heart p-1 m-1  rounded-circle border-secondary"></i>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}

export default ShopMain;
