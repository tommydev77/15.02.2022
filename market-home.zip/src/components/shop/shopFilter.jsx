function ShopFilter() {
  return (
    <>
      <div className="container">
        <div className="row pt-5 pb-2">
          <div className="col-md-3">
            <div className="fa-filters__title text-white my-3 bg-secondary rounded btn px-5 w-100">
              Filters
            </div>
          </div>
          <div className="col-md-9">
            <div className="row">
              <div className="col-sm-3">
                <select
                  name="Catergories"
                  id="o2"
                  className="text-white my-3 btn px-2 py-2 w-100 bg-warning rounded"
                >
                  <option value="cat">Catergories</option>
                </select>
              </div>
              <div className="col-sm-3">
                <select
                  name="Type"
                  id="ok1"
                  className="text-white my-3 btn px-2 py-2 w-100 bg-warning rounded"
                >
                  <option value="Type">Type</option>
                </select>
              </div>
              <div className="col-sm-3">
                <select
                  name="Color"
                  id="o2k"
                  className="text-white my-3 btn px-2 py-2 w-100 bg-warning rounded"
                >
                  <option value="Color">Color</option>
                </select>
              </div>
              <div className="col-sm-3">
                <button className="btn btn-warning rounded text-white my-3 py-1 w-100">
                  Popular
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}

export default ShopFilter;
