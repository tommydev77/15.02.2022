import React, { Component } from "react";
import ShopFilter from "./shopFilter";
import ShopSearch from "./shopSearch";
import FaProductLink from './FaProductLink';
import ShopMain from "./ShopMain.jsx";

import './shop.css';
class Shop extends Component {
  render() {
    return (
      <>
        <ShopSearch />
        <FaProductLink />
        <ShopFilter />
        <ShopMain />
      </>
    );
  }
}

export default Shop;
