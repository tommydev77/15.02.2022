function ShopSearch() {
  return (
    <>
      <div className="shop-title py-5 mb-5 my-3">
        <center>
          <h1 className="fw-bold">
            3D Objectlar makoniga <br />
            Xush kelibsiz!
          </h1>
        </center>
      </div>

      <div className="shop-search w-100 px-5">
        <div className="container">
          <div className="in-shop-search d-flex justify-content-center">
            <select name="categories" className="w-50 p-2" id="shop-select">
              <option value="null">CATEGORIES</option>
              <option value="home">Home</option>
              <option value="ok">Car</option>
            </select>

            <input type="text" className="w-100 p-2" />
            <i class="far fa-search w-20 p-2"></i>
          </div>
        </div>
      </div>


      <br /><br />
    </>
  );
}

export default ShopSearch;
